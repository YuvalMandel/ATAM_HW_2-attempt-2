################################# Instructions #################################
1) download idan_tests.zip and extract in the main folder where segel tests are.
2) write in command line: chmod +x idan_tests.sh
3) write in command line: ./idan_tests.sh

you can find the expected output, your output and the input files in /tests_idan/* folder.
Good Luck~